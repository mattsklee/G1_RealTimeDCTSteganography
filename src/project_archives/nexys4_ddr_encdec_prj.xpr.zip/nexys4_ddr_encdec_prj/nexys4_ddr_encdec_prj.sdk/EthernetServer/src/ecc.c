#include <stdio.h>
//#include <time.h>

void encode_4_bits(char bits[]){
  bits[4] = bits[0]^bits[1];
  bits[5] = bits[2]^bits[3];
  bits[6] = bits[0]^bits[2];
  bits[7] = bits[1]^bits[3];
}

void decode_4_bits(char bits[]){
  char expected_bits [8];
  int i;
  expected_bits[4] = bits[0]^bits[1];
  expected_bits[5] = bits[2]^bits[3];
  expected_bits[6] = bits[0]^bits[2];
  expected_bits[7] = bits[1]^bits[3];
  // If there are exactly 2 row/column errors, invert that row and column
  int err_count = 0;
  int row_index = -1;
  int col_index = -1;
  for (i = 4; i < 8; i++){
    if (expected_bits[i] != bits[i]){
      err_count += 1;
      if (i == 4 || i == 5)
        row_index = i-4;
      else
        col_index = i-6;
    }
  }
  if (err_count == 2 && row_index != -1 && col_index != -1){
    if (bits[row_index*2+col_index])
      bits[row_index*2+col_index] = 0;
    else
      bits[row_index*2+col_index] = 1;
  }
}

unsigned short error_correcting_encoder(char in_byte){
  unsigned short out = 0;
  char bits[8];
  int i;
  for (i = 0; i < 4; i++){
    bits[i] = (in_byte & (1<<i)) >> i;
  }
  encode_4_bits(bits);
  for (i = 0; i < 8; i++){
    out = out+(bits[i]<< i);
  }
  for (i = 4; i < 8; i++){
    bits[i-4] = (in_byte & (1<<i)) >> i;
  }
  encode_4_bits(bits);
  for (i = 8; i < 16; i++){
    out = out+(bits[i-8]<<i);
  }
  return out;
}

char error_correcting_decoder(short in){
  char out = 0;
  char bits[8];
  int i;
  for (i = 0; i < 8; i++){
    bits[i] = (in & (1<<i)) >> i;
  }
  decode_4_bits(bits);
  for (i = 0; i <4; i++){
    out = out + (bits[i]<< i);
  }
  for (i = 8; i < 16; i++){
    bits[i-8] = (in & (1<<i)) >> i;
  }
  decode_4_bits(bits);
  for (i = 4; i < 8; i++){
    out = out+(bits[i-4]<<i);
  }
  return out;
}
/*
int main(){
  int i;
  
  clock_t start = clock();
  for (i = 0; i < 100000; i++){
    char in_byte = 99;
    unsigned short out = error_correcting_encoder(in_byte);
    char out_2 = error_correcting_decoder(62545+i);
  }
  clock_t end = clock();
  float seconds = (float)(end - start) / CLOCKS_PER_SEC;
  printf("%f", seconds);
  char in_byte = 99;
  unsigned short out = error_correcting_encoder(in_byte);
  char out_2 = error_correcting_decoder(62545);
  //printf("%u", out_2);
}*/

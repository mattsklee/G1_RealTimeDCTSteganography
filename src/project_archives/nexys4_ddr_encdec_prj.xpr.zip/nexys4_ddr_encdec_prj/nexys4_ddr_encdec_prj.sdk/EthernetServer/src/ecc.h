#ifndef ECC_H
#define ECC_H
unsigned short error_correcting_encoder(char in_byte);
char error_correcting_decoder(short in);
#endif

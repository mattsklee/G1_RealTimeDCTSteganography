/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* XILINX CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <limits.h>
#include "ecc.h"

#include "lwip/err.h"
#include "lwip/tcp.h"
#ifdef __arm__
#include "xil_printf.h"
#endif

int transfer_data() {
	return 0;
}

void print_app_header()
{
	xil_printf("\n\r\n\r-----lwIP TCP echo server ------\n\r");
	xil_printf("TCP packets sent to port 6001 will be echoed back\n\r");
}

#define N_IM 26
#define START_LOC 0x80200000
#define STEG_BASE 0x44A00000
#define STEG_DECODER_BASE 0x44A10000
#define F_SIZE 0x100000
#define BUFSIZE 1400
#define NUM_BITS_SHIFT 0

#define MIN(X, Y) (((X) < (Y)) ? (X) : (Y))

//#define START_LOC_B 0x82100000
//#define START_LOC_C 0x84100000
typedef struct image{
	unsigned char* start;
	unsigned char* end;
} image;

int message = 0;
image fs[N_IM];
image* currim;
//char image_array[1000000];
unsigned char* currpos = (unsigned char*) START_LOC;
unsigned short error_correcting_encoder_table[256];
char error_correcting_decoder_table[65536];

err_t recv_callback(void *arg, struct tcp_pcb *tpcb,
                               struct pbuf *p, err_t err)
{
	/* do not read the packet if we are not in ESTABLISHED state */
	if (!p) {
		tcp_close(tpcb);
		tcp_recv(tpcb, NULL);
		return ERR_OK;
	}
	char decode_buf[BUFSIZE];
	unsigned char mask = (1 << NUM_BITS_SHIFT) - 1;
	unsigned back_shift = 8 - NUM_BITS_SHIFT;

	int i;
	/* indicate that the packet has been received */
	tcp_recved(tpcb, p->len);

	static int total_recved = 0;
	total_recved += p->len;
	//xil_printf("Got packet: \n\n %s \n\n", (char*) p->payload);
	//xil_printf("Got packet of length: %d\n", p->len);
	//xil_printf("Total received so far: %d\n", total_recved);
	//int sndbuf;

	if(strcmp((char*)p->payload, "ReadFile") == 0){
		//xil_printf("Attempting to read %d bytes, left = %d bytes\r\n", BUFSIZE, currim->end - currpos);
		//xil_printf("currpos: %x, currim->end: %x\n", (unsigned) currpos,  (unsigned) currim->end);

		int sendlen = MIN((currim->end - currpos), BUFSIZE);
		if(message){
			if(sendlen == 0){
				tcp_write(tpcb, "done reading", 12, 1);
			}else{
				for(i = 0; i < sendlen; i++){
					currpos[0] = (currpos[0] >> NUM_BITS_SHIFT) | ((currpos[1] & mask) << back_shift);
					currpos[1] = (currpos[1] >> NUM_BITS_SHIFT) | ((currpos[2] & mask) << back_shift);
					decode_buf[i] = error_correcting_decoder_table[ *((unsigned short*) currpos) ];
					currpos += 2;
				}
				//xil_printf("%s\n", decode_buf);
				tcp_write(tpcb, decode_buf, sendlen, 1);
			}

		}
		else{
			if(sendlen == 0){
				tcp_write(tpcb, "done reading", 12, 1);
			}else{
				tcp_write(tpcb, currpos, sendlen, 1);
				currpos += sendlen;
			}
		}
	} else if(strncmp((char*)p->payload, "Open Image ", 11) == 0) {
		int o = ((char*)p->payload)[11] - 'A';

		message = 0;
		if(o != 0 && fs[o-1].start == 0 ){
			xil_printf("Create image %c before image %c\n", o + 'A' - 1, o + 'A');
		}else if(fs[o].start == 0){
			xil_printf("Creating image %c\n", o + 'A');
			currim = &fs[o];
			currim->start = fs[o-1].end + 1;
			currim->end = currim->start;
			currpos = currim->start;
		}else{
			xil_printf("Opening image %c\n", o + 'A');
			currim = &fs[o];
			currpos = currim->start;
		}
		err = tcp_write(tpcb, "image opened", 12, 1);

	} else if(strncmp((char*)p->payload, "Open Message ", 13) == 0) {
		int o = ((char*)p->payload)[13] - 'A';

		message = 1;
		if(o != 0 && fs[o-1].start == 0 ){
			xil_printf("Create message %c before image %c\n", o + 'A' - 1, o + 'A');
		}else if(fs[o].start == 0){
			xil_printf("Creating message %c\n", o + 'A');
			currim = &fs[o];
			currim->start = fs[o-1].end + 1;
			currim->end = currim->start;
			currpos = currim->start;
		}else{
			xil_printf("Opening message %c\n", o + 'A');
			currim = &fs[o];
			currpos = currim->start;
		}
		err = tcp_write(tpcb, "message opened", 14, 1);

	}
	else if(strncmp((char*)p->payload, "set_cover ", 10) == 0){
		int o = ((char*)p->payload)[10] - 'A';
		((volatile int*) STEG_BASE)[0] = (int) fs[o].start;
		xil_printf("Set cover image to %c\n", o + 'A');
		err = tcp_write(tpcb, "Set cover", 10, 1);
	}
	else if(strncmp((char*)p->payload, "set_stego ", 10) == 0){
		int o = ((char*)p->payload)[10] - 'A';
		((volatile int*) STEG_BASE)[1] = (int) fs[o].start;
		xil_printf("Set stego image to %c\n", o + 'A');
		err = tcp_write(tpcb, "Set stego", 10, 1);
	}
	else if(strncmp((char*)p->payload, "set_message ", 12) == 0){
		int o = ((char*)p->payload)[12] - 'A';
		((volatile int*) STEG_BASE)[2] = (int) fs[o].start;
		xil_printf("Set message to %c\n", o + 'A');
		err = tcp_write(tpcb, "Set message", 12, 1);
	}
	else if(strncmp((char*)p->payload, "set_decoder_stego ", 18) == 0){
		int o = ((char*)p->payload)[18] - 'A';
		((volatile int*) STEG_DECODER_BASE)[1] = (int) fs[o].start;
		xil_printf("Set decoder stego image to %c\n", o + 'A');
		err = tcp_write(tpcb, "Set decoder stego", 18, 1);
	}
	else if(strncmp((char*)p->payload, "set_decoder_message ", 20) == 0){
		int o = ((char*)p->payload)[20] - 'A';
		((volatile int*) STEG_DECODER_BASE)[2] = (int) fs[o].start;
		xil_printf("Set decoder message to %c\n", o + 'A');
		err = tcp_write(tpcb, "Set decoder message", 20, 1);
	}
	else if(strcmp((char*)p->payload, "begin encoding") == 0){
		((volatile int*) STEG_BASE)[3] = 1;
		xil_printf("Encoding begun\n");
		err = tcp_write(tpcb, "Encoding begun", 15, 1);
	}
	else if(strcmp((char*)p->payload, "begin decoding") == 0){
		((volatile int*) STEG_DECODER_BASE)[3] = 1;
		xil_printf("Decoding begun\n");
		err = tcp_write(tpcb, "Decoding begun", 15, 1);
	}
	else if(strcmp((char*)p->payload, "check done encoding") == 0){
		int done_enc = ((volatile int*) STEG_BASE)[4];
		xil_printf("Done encoding value: %x\n", done_enc);
		done_enc &= 1;
		if(done_enc){
			xil_printf("Done encoding\n");
			err = tcp_write(tpcb, "Done encoding", 14, 1);
		}else{
			xil_printf("Not done encoding\n");
			err = tcp_write(tpcb, "Not done encoding", 18, 1);
		}
	}
	else if(strcmp((char*)p->payload, "check done decoding") == 0){
		int done_enc = ((volatile int*) STEG_DECODER_BASE)[4];
		xil_printf("Done decoding value: %x\n", done_enc);
		done_enc &= 1;
		if(done_enc){
			xil_printf("Done decoding\n");
			err = tcp_write(tpcb, "Done decoding", 14, 1);
		}else{
			xil_printf("Not done decoding\n");
			err = tcp_write(tpcb, "Not done decoding", 18, 1);
		}
	}
	else {
		//xil_printf("writing data\n");
		unsigned short idx;
		if(message){
			for(i = 0; i < p->len; i++){
				//xil_printf("%x", error_correcting_encoder(((char*) p->payload)[i]));
				idx = ((unsigned char*) p->payload)[i];
				*((short*) currpos) = error_correcting_encoder_table[ idx ];
				currpos += 2;
			}
			//xil_printf("%s\n", (char*) p->payload);
			err = tcp_write(tpcb, "message data written", 20, 1);
		}
		else {
			memcpy(currpos, p->payload, p->len);
			currpos += p->len;
			//if(currpos > currim->end) currim->end = currpos;
			err = tcp_write(tpcb, "image data written", 18, 1);
		}
	}

	/* echo back the payload */
	/* in this case, we assume that the payload is < TCP_SND_BUF */
	/*if (tcp_sndbuf(tpcb) > p->len) {
		err = tcp_write(tpcb, p->payload, p->len, 1);
	} else
		xil_printf("no space in tcp_sndbuf\n\r");*/

	/* free the received pbuf */
	pbuf_free(p);

	return ERR_OK;
}

err_t accept_callback(void *arg, struct tcp_pcb *newpcb, err_t err)
{
	static int connection = 1;

	/* set the receive callback for this connection */
	tcp_recv(newpcb, recv_callback);

	/* just use an integer number indicating the connection id as the
	   callback argument */
	tcp_arg(newpcb, (void*)connection);

	/* increment for subsequent accepted connections */
	connection++;

	return ERR_OK;
}


int start_application()
{
	struct tcp_pcb *pcb;
	err_t err;
	unsigned port = 7;

	/* create new TCP PCB structure */
	pcb = tcp_new();
	if (!pcb) {
		xil_printf("Error creating PCB. Out of Memory\n\r");
		return -1;
	}

	/* bind to specified @port */
	err = tcp_bind(pcb, IP_ADDR_ANY, port);
	if (err != ERR_OK) {
		xil_printf("Unable to bind to port %d: err = %d\n\r", port, err);
		return -2;
	}

	/* we do not need any arguments to callback functions */
	tcp_arg(pcb, NULL);

	/* listen for connections */
	pcb = tcp_listen(pcb);
	if (!pcb) {
		xil_printf("Out of memory while tcp_listen\n\r");
		return -3;
	}

	/* specify callback to use for incoming connections */
	tcp_accept(pcb, accept_callback);
	int i;
	for(i = 0; i < N_IM; i++){
		fs[i].start = (unsigned char*) START_LOC + i*(1<<22);
		fs[i].end = (unsigned char*) START_LOC + (i+1)*(1<<22) - 1;
	}

	for(i = 0; i < 256; i++)
		error_correcting_encoder_table[i] = error_correcting_encoder((char) i);

	for(i = 0; i <  65536; i++)
		error_correcting_decoder_table[i] = error_correcting_decoder((unsigned short) i);

	xil_printf("TCP echo server started @ port %d\n\r", port);

	return 0;
}

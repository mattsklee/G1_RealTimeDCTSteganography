
#include "vdma1.h"

#define OFFSET_READ 1920 * 3 * 4
#define OFFSET_WRITE 1920 * 3 * 4

void ReadConfig(XAxiVdma *vdma,
                XAxiVdma_DmaSetup *vdmaConfig,
                XAxiVdma_FrameCounter *frame_count_config)
{
  int Status;

  // Config VDMA
  vdmaConfig->VertSizeInput = 1;
  vdmaConfig->HoriSizeInput = OFFSET_READ;
  vdmaConfig->Stride = OFFSET_READ;
  vdmaConfig->FrameDelay = 0;
  vdmaConfig->EnableCircularBuf = 1;
  vdmaConfig->EnableSync = 0;
  vdmaConfig->PointNum = 1;
  vdmaConfig->EnableFrameCounter = 1;

  Status = XAxiVdma_DmaConfig(vdma, XAXIVDMA_READ, (vdmaConfig));
  if (Status != XST_SUCCESS)
  {
    xil_printf("Read DmaConfig failed %d\n\r", Status);
  }
}


int DMAReadFromMem(int ind, XAxiVdma *vdma, XAxiVdma_DmaSetup *vdmaConfig, XAxiVdma_FrameCounter *frame_count_config, u8 *Frame_1)
{
  int Status;

  vdmaConfig->FrameStoreStartAddr[0] = (u32) (Frame_1 + ind*OFFSET_READ);

  Status = XAxiVdma_DmaSetBufferAddr(vdma, XAXIVDMA_READ,(vdmaConfig->FrameStoreStartAddr));
  if (Status != XST_SUCCESS)
  {
    xil_printf( "Read DmaSetBufferAddr failed %d\n\r", Status);
    return XST_FAILURE;
  }
  Status = XAxiVdma_DmaStart(vdma, XAXIVDMA_READ);

  if (Status != XST_SUCCESS)
  {
    xil_printf( "Read DmaStart failed %d\n\r", Status);
    return XST_FAILURE;
  }
  return XST_SUCCESS;
}

void WriteConfig(XAxiVdma *vdma,
                 XAxiVdma_DmaSetup *vdmaConfig,
                 XAxiVdma_FrameCounter *frame_count_config)
{

  int Status;

  // Config VDMA
  vdmaConfig->VertSizeInput = 1;
  vdmaConfig->HoriSizeInput = OFFSET_WRITE;
  vdmaConfig->Stride = OFFSET_WRITE;
  vdmaConfig->FrameDelay = 0;
  vdmaConfig->EnableCircularBuf = 0;
  vdmaConfig->EnableSync = 0;
  vdmaConfig->PointNum = 1;
  vdmaConfig->EnableFrameCounter = 1;

  Status = XAxiVdma_DmaConfig(vdma, XAXIVDMA_WRITE, vdmaConfig);
  if (Status != XST_SUCCESS)
  {
    xil_printf( "Write DmaConfig %d\n\r", Status);
  }
}


int DMAWriteToMem(int ind, XAxiVdma *vdma, XAxiVdma_DmaSetup *vdmaConfig, XAxiVdma_FrameCounter *frame_count_config, u8 *Frame_1)
{
  int Status;

  vdmaConfig->FrameStoreStartAddr[0] = (u32) (Frame_1 + (ind)*OFFSET_WRITE);

  Status = XAxiVdma_DmaSetBufferAddr(vdma, XAXIVDMA_WRITE, vdmaConfig->FrameStoreStartAddr);
  if (Status != XST_SUCCESS)
  {
    xil_printf( "Write DmaSetBufferAddr failed %d\n\r", Status);
    return XST_FAILURE;
  }

  Status = XAxiVdma_DmaStart(vdma, XAXIVDMA_WRITE);
  if (Status != XST_SUCCESS)
  {
    xil_printf("Write DmaStart failed %d\n\r", Status);
    return XST_FAILURE;
  }


  return XST_SUCCESS;
}

